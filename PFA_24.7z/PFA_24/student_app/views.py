from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Student, Grade, Timetable, Absence
from .utils import send_suspicious_behavior_email
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import base64
import face_recognition
import numpy as np
import json
import cv2

@login_required
def student_dashboard(request):
    student = Student.objects.get(user=request.user)
    grades = Grade.objects.filter(student=student)
    timetable = Timetable.objects.filter(classroom=student.classroom)
    absences = Absence.objects.filter(student=student)
    context = {
        'student': student,
        'grades': grades,
        'timetable': timetable,
        'absences': absences,
    }
    return render(request, 'student_dashboard.html', context)

def initialize_face_encodings():
    known_face_encodings = []
    known_face_names = []

    students = Student.objects.all()
    for student in students:
        encoding = student.get_face_encoding()
        if encoding is not None:
            known_face_encodings.append(encoding)
            known_face_names.append(f'{student.first_name} {student.last_name}')

    return known_face_encodings, known_face_names

known_face_encodings, known_face_names = initialize_face_encodings()

@csrf_exempt
def detect_presence(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            image_data = data['image'].split(',')[1]
            image = base64.b64decode(image_data)
            nparr = np.frombuffer(image, np.uint8)
            img_np = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            # Convertir l'image BGR en RGB
            rgb_img = img_np[:, :, ::-1]

            # Détecter les visages et leurs encodages dans l'image
            face_locations = face_recognition.face_locations(rgb_img)
            face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

            names = []
            for face_encoding in face_encodings:
                # Comparer les visages détectés avec les visages de référence
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                name = "Inconnu"

                # Utiliser le visage de référence avec la distance la plus faible
                face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = known_face_names[best_match_index]

                names.append(name)

            return render(request, 'detect_presence_result.html', {'names': names})
        except Exception as e:
            return render(request, 'detect_presence_result.html', {'error': str(e)})
    return render(request, 'detect_presence.html', {'error': 'Invalid request'})

@login_required
def exam_mode(request):
    if request.method == 'POST':
        # Simuler la détection de comportement suspect
        student = request.user.student
        professors = student.classroom.professors.all()
        for professor in professors:
            send_suspicious_behavior_email(professor.user.email, student.user.get_full_name())
        return render(request, 'exam_mode.html', {'message': 'Comportement suspect détecté, notification envoyée.'})
    return render(request, 'exam_mode.html')
