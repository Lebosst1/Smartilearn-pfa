# student_app/utils.py
from django.core.mail import send_mail
from django.conf import settings

def send_suspicious_behavior_email(professor_email, student_name):
    subject = 'Alerte : Comportement suspect détecté'
    message = f'Un comportement suspect a été détecté chez l\'étudiant {student_name} pendant l\'examen.'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [professor_email]
    send_mail(subject, message, email_from, recipient_list)



