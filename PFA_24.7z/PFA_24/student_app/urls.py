from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.student_dashboard, name='student_dashboard'),
    path('detect_presence/', views.detect_presence, name='detect_presence'),
    path('exam_mode/', views.exam_mode, name='exam_mode'),
]
