from django.db import models
from auth_app.models import User
import face_recognition
import numpy as np
from PIL import Image
import io


# Create your models here.
class Classroom(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Subject(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='photos/')
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='student_app_students')

    def __str__(self):
        return f'{self.first_name} {self.last_name}'

    def get_face_encoding(self):
        if not self.photo:
            return None
        image = face_recognition.load_image_file(self.photo.path)
        encodings = face_recognition.face_encodings(image)
        if encodings:
            return encodings[0]
        return None

class Grade(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    grade = models.FloatField()

    def __str__(self):
        return f'{self.student} - {self.subject} : {self.grade}'

class Timetable(models.Model):
    DAY_CHOICES = [
        ('LUN', 'Lundi'),
        ('MAR', 'Mardi'),
        ('MER', 'Mercredi'),
        ('JEU', 'Jeudi'),
        ('VEN', 'Vendredi'),
        ('SAM', 'Samedi'),
        ('DIM', 'Dimanche'),
    ]

    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='timetable')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    day = models.CharField(max_length=3, choices=DAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    room = models.CharField(max_length=50)

    def __str__(self):
        return f'{self.get_day_display()} {self.start_time} - {self.end_time} : {self.subject.name}'

class Absence(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    timetable = models.ForeignKey(Timetable, on_delete=models.CASCADE)
    date = models.DateField()

    def __str__(self):
        return f'{self.student} - {self.timetable} : {self.date}'