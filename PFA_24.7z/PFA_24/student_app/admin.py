from django.contrib import admin
from .models import Student,Classroom,Timetable,Grade,Absence,Subject 
# Register your models here.
admin.site.register(Student)
admin.site.register(Classroom)
admin.site.register(Grade)
admin.site.register(Timetable)
admin.site.register(Absence)
admin.site.register(Subject)