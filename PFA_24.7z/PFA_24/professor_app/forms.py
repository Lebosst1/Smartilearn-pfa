
from django import forms
from .models import StudentBehavior

class StudentBehaviorForm(forms.ModelForm):
    class Meta:
        model = StudentBehavior
        fields = ['student', 'participation_level', 'engagement_level', 'concentration_level', 'date']
