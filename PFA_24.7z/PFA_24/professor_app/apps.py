from django.apps import AppConfig


class ProfessorAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "professor_app"
