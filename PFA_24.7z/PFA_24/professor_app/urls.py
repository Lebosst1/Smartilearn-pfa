# urls.py in auth_app
from django.urls import path
from . import views

urlpatterns = [
    
     path('dashboard/', views.professor_dashboard, name='professor_dashboard'),
     path('record_behavior/', views.record_behavior, name='record_behavior'),
     path('analyze_behavior/', views.analyze_behavior, name='analyze_behavior'),
   
]
