from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def professor_dashboard(request):
    return render(request, 'professor_dashboard.html')

from .models import StudentBehavior

from .models import StudentBehavior

from django.shortcuts import render, redirect
from .models import StudentBehavior
from .forms import StudentBehaviorForm  # Assurez-vous d'importer le formulaire approprié

def record_behavior(request):
    if request.method == 'POST':
        form = StudentBehaviorForm(request.POST)
        if form.is_valid():
            form.save()
            # Redirection vers une page de succès ou une autre vue
            return redirect('record_behavior_success')
        # Si le formulaire n'est pas valide, réafficher le formulaire avec les erreurs
    else:
        form = StudentBehaviorForm()
    return render(request, 'record_behavior.html', {'form': form})

def analyze_behavior(request):
    behaviors = StudentBehavior.objects.all()
    # Ajoutez ici la logique d'analyse des comportements
    return render(request, 'analyze_behavior.html', {'behaviors': behaviors})