from django.db import models
from student_app.models import Subject, Classroom,Student
from auth_app.models import User

# Create your models here.
class Professor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None)  # Assurez-vous que default est défini sur None
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='professors')
    classrooms = models.ManyToManyField(Classroom, related_name='professors')
    
    def __str__(self):
        return f'{self.first_name} {self.last_name}'


class StudentBehavior(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    date = models.DateField()
    participation_level = models.CharField(max_length=50)
    engagement_level = models.CharField(max_length=50)
    concentration_level = models.CharField(max_length=50)

    def __str__(self):
        return f'{self.student} - {self.date}'