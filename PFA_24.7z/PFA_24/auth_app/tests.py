import os
import sys
import django
from django.test import TestCase
from django.contrib.auth import get_user_model

# Ajouter le répertoire du projet au sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartilearn.settings')
django.setup()

class UserModelTest(TestCase):
    def setUp(self):
        User = get_user_model()
        User.objects.create_user(username='adminuser', password='password123', user_type='admin')
        User.objects.create_user(username='professoruser', password='password123', user_type='professor')
        User.objects.create_user(username='studentuser', password='password123', user_type='student')

    def test_user_creation(self):
        User = get_user_model()
        users = User.objects.all()
        self.assertTrue(users.exists())
        self.assertEqual(users.count(), 3)
        self.assertTrue(User.objects.filter(username='adminuser').exists())
        self.assertTrue(User.objects.filter(username='professoruser').exists())
        self.assertTrue(User.objects.filter(username='studentuser').exists())
