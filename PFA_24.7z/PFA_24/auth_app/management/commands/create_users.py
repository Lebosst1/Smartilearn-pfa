from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from admin_app.models import Admin
from auth_app.models import User
from professor_app.models import Professor
from student_app.models import Student
from student_app.models import Classroom  as StudentClassroom # Assurez-vous d'importer votre modèle Classroom

class Command(BaseCommand):
    help = 'Create users from existing instances of Admin, User, Professor, and Student'

    def handle(self, *args, **options):
        User = get_user_model()
        
        # Create users from Admin instances
        for admin in Admin.objects.all():
            username = admin.first_name.lower() + admin.last_name.lower()
            try:
                user = User.objects.get(username=username)
            except User.DoesNotExist:
                user = User.objects.create_user(
                    username=username,
                    user_type='admin'
                )

        # Create users from Professor instances
        for professor in Professor.objects.all():
            username = professor.first_name.lower() + professor.last_name.lower()
            try:
                user = User.objects.get(username=username)
            except User.DoesNotExist:
                user = User.objects.create_user(
                    username=username,
                    user_type='professor'
                )

        # Create users from Student instances
        for student in Student.objects.all():
            username = student.first_name.lower() + student.last_name.lower()
            try:
                user = User.objects.get(username=username)
            except User.DoesNotExist:
                user = User.objects.create_user(
                    username=username,
                    user_type='student'
                )

        # Ensure Default Classroom exists for Students
        try:
            default_classroom = StudentClassroom.objects.filter(name='Default Classroom').first()
        except StudentClassroom.DoesNotExist:
            # Handle the case where 'Default Classroom' doesn't exist
            pass
        except StudentClassroom.MultipleObjectsReturned:
            # Handle the case where multiple 'Default Classroom' objects exist
            # For example, you could log a warning or choose one of the instances to use
            pass
