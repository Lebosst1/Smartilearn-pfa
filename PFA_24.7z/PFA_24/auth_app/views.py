from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from auth_app.forms import CustomAuthenticationForm

def login_view(request):
    error_message = None
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        
        if form.is_valid():
            print("mal fait btrrrrrrrrrr")
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # Utilisation du backend personnalisé pour l'authentification
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                if user.user_type == 'student':
                    return redirect('student_dashboard')
                elif user.user_type == 'professor':
                    return redirect('professor_dashboard')
                elif user.user_type == 'admin':
                    return redirect('admin_dashboard')
            else:
                error_message = "Nom d'utilisateur ou mot de passe incorrect."
        else:
            # Déboguer les erreurs de formulaire
            print("Form errors:", form.errors)
            error_message = "Formulaire invalide. Veuillez vérifier les champs."
    else:
        form = CustomAuthenticationForm()

    return render(request, 'login.html', {'form': form, 'error_message': error_message})



from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import User
from student_app.models import Student ,Subject,Classroom
from admin_app.models import Admin
from professor_app.models import Professor

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        if instance.user_type == 'admin':
            Admin.objects.create(user=instance)
        elif instance.user_type == 'professor':
            Professor.objects.create(user=instance)
        elif instance.user_type == 'student':
            # Créer une salle de classe si aucune n'existe encore
            classroom, created = Classroom.objects.get_or_create(defaults={'name': 'Default Classroom'})
            Student.objects.create(user=instance, classroom=classroom)




from django.contrib.auth import get_user_model
from django.http import HttpResponse

def debug_view(request):
    User = get_user_model()
    users = User.objects.all()
    user_list = ', '.join([f"User: {user.username}, Type: {user.user_type}" for user in users])
    return HttpResponse(f"Users: {user_list}")            