from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from student_app.models import Student, Subject,Classroom
from professor_app.models import Professor
from auth_app.models import User
from django.contrib import messages
from .forms import StudentForm
@login_required
def admin_home(request):
    return render(request, 'admin_dashboard.html')

@login_required
def manage_students(request):
    students = Student.objects.all()
    return render(request, 'manage_students.html', {'students': students})

@login_required
def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # Vérifier si l'utilisateur existe déjà
            user, created = User.objects.get_or_create(username=username)
            if created:
                user.set_password(password)
                user.save()
            # Créer l'étudiant et l'associer à l'utilisateur
            student = Student.objects.create(
                user=user,
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
                classroom=form.cleaned_data['classroom'],
                photo=form.cleaned_data['photo']
            )
            return redirect('admin_dashboard')  # Rediriger vers la page d'administration
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})

@login_required
def view_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    return render(request, 'view_student.html', {'student': student})

@login_required
def delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    student.delete()
    messages.success(request, "Étudiant supprimé avec succès.")
    return redirect('manage_students')

@login_required
def add_professor(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        subject_id = request.POST['subject_id']
        # Ajoutez ici les autres champs nécessaires pour créer un professeur
        user = User.objects.create_user(username=email, email=email, first_name=first_name, last_name=last_name, user_type='professor')
        subject = Subject.objects.get(id=subject_id)
        Professor.objects.create(user=user, first_name=first_name, last_name=last_name, subject=subject)
        messages.success(request, "Professeur ajouté avec succès !")
        return redirect('admin_dashboard_manage_professors')
    return render(request, 'add_professor.html')

@login_required
def view_professor(request, professor_id):
    professor = get_object_or_404(Professor, id=professor_id)
    return render(request, 'view_professor.html', {'professor': professor})

@login_required
def edit_professor(request, professor_id):
    professor = get_object_or_404(Professor, id=professor_id)
    if request.method == 'POST':
        professor.first_name = request.POST['first_name']
        professor.last_name = request.POST['last_name']
        professor.subject_id = request.POST['subject_id']
        # Ajoutez ici les autres champs nécessaires pour mettre à jour un professeur
        professor.save()
        messages.success(request, "Professeur mis à jour avec succès.")
        return redirect('admin_dashboard_manage_professors')
    return render(request, 'edit_professor.html', {'professor': professor})

@login_required
def delete_professor(request, professor_id):
    professor = get_object_or_404(Professor, id=professor_id)
    professor.delete()
    messages.success(request, "Professeur supprimé avec succès.")
    return redirect('admin_dashboard_manage_professors')

@login_required
def admin_dashboard_manage_professors(request):
    professors = Professor.objects.all()
    return render(request, 'manage_professors.html', {'professors': professors})
