from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.admin_home, name='admin_dashboard'),
    path('manage_students/', views.manage_students, name='manage_students'),
    path('add_student/', views.add_student, name='add_student'),
    path('view_student/<int:student_id>/', views.view_student, name='view_student'),
    path('delete_student/<int:student_id>/', views.delete_student, name='delete_student'),
    path('add_professor/', views.add_professor, name='add_professor'),
    path('view_professor/<int:professor_id>/', views.view_professor, name='view_professor'),
    path('edit_professor/<int:professor_id>/', views.edit_professor, name='edit_professor'),
    path('delete_professor/<int:professor_id>/', views.delete_professor, name='delete_professor'),
    path('manage_professors/', views.admin_dashboard_manage_professors, name='admin_dashboard_manage_professors'),
]
