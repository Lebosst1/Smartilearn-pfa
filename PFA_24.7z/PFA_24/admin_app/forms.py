from django import forms
from student_app.models import Student

class StudentForm(forms.ModelForm):
    username = forms.CharField(label='Nom d\'utilisateur', max_length=150)  # Champ pour le nom d'utilisateur
    password = forms.CharField(label='Mot de passe', widget=forms.PasswordInput)  # Champ pour le mot de passe

    class Meta:
        model = Student
        fields = ['username', 'password', 'first_name', 'last_name', 'photo', 'classroom']
